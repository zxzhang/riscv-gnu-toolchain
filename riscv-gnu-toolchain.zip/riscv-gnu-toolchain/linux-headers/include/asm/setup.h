/* SPDX-License-Identifier: GPL-2.0-only WITH Linux-syscall-note */

#ifndef _ASM_RISCV_SETUP_H
#define _ASM_RISCV_SETUP_H

#define COMMAND_LINE_SIZE	1024

#endif /* _ASM_RISCV_SETUP_H */
